<html>
<head>
<title>A BASIC HTML FORM</title>
<body>
<table border=1 width=100%  cellspacing="1" cellpadding="1">


<!--    cnbc PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_cnbc = array();

					 if(($handle_cnbc = fopen("data/cnbc.csv", "r")) !== FALSE)
					 {
					    while(($data_cnbc = fgetcsv($handle_cnbc,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_cnbc[] = $data_cnbc;
					    }
					 }

 					fclose($handle_cnbc);
							$result_cnbc = sizeof($csv_cnbc);



							echo '<td bgcolor ="#DCDCDC">'.$csv_cnbc[1][0]. '</td></tr>';

							for($i = 1; $i < $result_cnbc ; $i++) {
							if (9 < strlen($csv_cnbc[$i][8]) ){
				echo '<td bgcolor=#FFFFF0><img src="'.$csv_cnbc[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_cnbc[$i][7].'" target="_blank">'. substr($csv_cnbc[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_cnbc[$i][8],0,11)  .') </i>'   .
																 				'<br>' . substr($csv_cnbc[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>


</table>
</td></tr>

<!-- ===================   END  cnbc============================== -->

<!--    theguardian PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_theguardian = array();

					 if(($handle_theguardian = fopen("data/theguardian.csv", "r")) !== FALSE)
					 {
					    while(($data_theguardian = fgetcsv($handle_theguardian,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_theguardian[] = $data_theguardian;
					    }
					 }

 					fclose($handle_theguardian);
							$result_theguardian = sizeof($csv_theguardian);



							echo '<td bgcolor ="#DCDCDC">'.$csv_theguardian[1][0]. '</td></tr>';

							for($i = 1; $i < $result_theguardian ; $i++) {
							if (9 < strlen($csv_theguardian[$i][8]) ){
				echo '<td bgcolor=#FFFFF0><img src="'.$csv_theguardian[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_theguardian[$i][7].'" target="_blank">'. substr($csv_theguardian[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_theguardian[$i][8],0,11)  .') </i>'   .
																 				'<br>' . substr($csv_theguardian[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>


</table>
</td></tr>

<!-- ===================   END  theguardian============================== -->


<!--    drudgereport SECOND PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_drudgereport = array();

					 if(($handle_drudgereport = fopen("data/drudgereport.csv", "r")) !== FALSE)
					 {
					    while(($data_drudgereport = fgetcsv($handle_drudgereport,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_drudgereport[] = $data_drudgereport;
					    }
					 }

 					fclose($handle_drudgereport);
							$result_drudgereport = sizeof($csv_drudgereport);



							echo '<td bgcolor ="#C36241">'.$csv_drudgereport[1][0]. '</td></tr>';

							for($i = 1; $i < $result_drudgereport ; $i++) {
							if (9 < strlen($csv_drudgereport[$i][8]) ){
				echo '<td bgcolor=#FFDAB9><img src="'.$csv_drudgereport[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_drudgereport[$i][7].'" target="_blank">'. substr($csv_drudgereport[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_drudgereport[$i][8],0,11)  .') </i>'   .
																 				'<br>' . substr($csv_drudgereport[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>


</table>
</td></tr>
<!-- End of drudgereport --->


<!-- ROW 1 -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
$csv_politico = array();
$row = 1;
 if(($handle_politico = fopen("data/politico.csv", "r")) !== FALSE)
 {
    while(($data_politico = fgetcsv($handle_politico,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\" )) !== FALSE)
    {

 #   $num = count($data_politico);
#	        echo "<p> $num fields in line $row: <br /></p>\n";
#	        $row++;
#	        for ($c=0; $c < $num; $c++) {
#	            echo $data_politico[$c] . "<br />\n";
 #       }

        $csv_politico[] = $data_politico;
    }
 }

 fclose($handle_politico);
 $result_politico = sizeof($csv_politico);

#echo $csv_politico[1][0].'\n';
#echo strlen($csv_politico[$i][8]);
#echo 'HELP'.$result_politico;

#echo '<tr> <td width=50%>';

echo '<td bgcolor ="#98AFC7">'.$csv_politico[1][0]. '</td></tr>';


for($i = 1; $i < $result_politico ; $i++) {

#echo strlen($csv_politico[$i][8]);

if (9 < strlen($csv_politico[$i][8]) ){
echo '<td bgcolor=#F0F8FF border=0><img src="'.$csv_politico[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_politico[$i][7].'" target="_blank">'. substr($csv_politico[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_politico[$i][8],0,11)  .') </i>'   .
																 				'<br>' . substr($csv_politico[$i][4],0,500) .
							'</td></tr>';
'</font></td></tr>';
}


}

?>


</table>
</td></tr>
<!--    newsmax SECOND PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_newsmax = array();

					 if(($handle_newsmax = fopen("data/newsmax.csv", "r")) !== FALSE)
					 {
					    while(($data_newsmax = fgetcsv($handle_newsmax,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_newsmax[] = $data_newsmax;
					    }
					 }

 					fclose($handle_newsmax);
							$result_newsmax = sizeof($csv_newsmax);


							#echo '<tr> <th width=50%>';

							echo '<td bgcolor ="#C36241">'.$csv_newsmax[1][0]. '</td></tr>';

							for($i = 1; $i < $result_newsmax ; $i++) {
							if (9 < strlen($csv_newsmax[$i][8]) ){
				echo '<td bgcolor=#FFDAB9><img src="'.$csv_newsmax[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_newsmax[$i][7].'" target="_blank">'. substr($csv_newsmax[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_newsmax[$i][8],0,11)  .') </i>'   .
																 				'<br>' . substr($csv_newsmax[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>


</table>
</td></tr>
<!-- End of newsmax --->

<!--    washingtonpost PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_washingtonpost = array();

					 if(($handle_washingtonpost = fopen("data/washingtonpost.csv", "r")) !== FALSE)
					 {
					    while(($data_washingtonpost = fgetcsv($handle_washingtonpost, $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_washingtonpost[] = $data_washingtonpost;
					    }
					 }

 					fclose($handle_washingtonpost);
							$result_washingtonpost = sizeof($csv_washingtonpost);


							#echo '<tr> <th width=50%>';
							#echo $result_washingtonpost;

							echo '<td bgcolor ="#98AFC7">'.$csv_washingtonpost[1][0]. '</td></tr>';

							for($i = 1; $i < $result_washingtonpost; $i++) {
							if (9 < strlen($csv_washingtonpost[$i][8]) )

							{
				echo '<td bgcolor=#F0F8FF><img src="'.$csv_washingtonpost[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_washingtonpost[$i][7].'" target="_blank">'. substr($csv_washingtonpost[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_washingtonpost[$i][8],0,11)  .') </i>'   .
									 				'<br>' . substr($csv_washingtonpost[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>


</table>
</td></tr>
<!--  ---------===============    END washingtonpost ==========   --->

<!--    realclearpolitics PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_realclearpolitics = array();

					 if(($handle_realclearpolitics = fopen("data/realclearpolitics.csv", "r")) !== FALSE)
					 {
					    while(($data_realclearpolitics = fgetcsv($handle_realclearpolitics,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_realclearpolitics[] = $data_realclearpolitics;
					    }
					 }

 					fclose($handle_realclearpolitics);
							$result_realclearpolitics = sizeof($csv_realclearpolitics);



							echo '<td bgcolor ="#C36241">'.$csv_realclearpolitics[1][0]. '</td></tr>';

							for($i = 1; $i < $result_realclearpolitics ; $i++) {
							if (9 < strlen($csv_realclearpolitics[$i][8]) ){
				echo '<td bgcolor=#FFDAB9><img src="'.$csv_realclearpolitics[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_realclearpolitics[$i][7].'" target="_blank">'. substr($csv_realclearpolitics[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_realclearpolitics[$i][8],0,11)  .')</i> '   .
																 				'<br>' . substr($csv_realclearpolitics[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>


</table>
</td></tr>

<!-- ===================   END  realclearpolitics============================== -->

<!--    CNN PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_cnn = array();

					 if(($handle_cnn = fopen("data/cnn.csv", "r")) !== FALSE)
					 {
					    while(($data_cnn = fgetcsv($handle_cnn,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_cnn[] = $data_cnn;
					    }
					 }

 					fclose($handle_cnn);
							$result_cnn = sizeof($csv_cnn);


							#echo $result_cnn;

							echo '<td bgcolor ="#98AFC7">'.$csv_cnn[1][0]. '</td></tr>';

							for($i = 1; $i < $result_cnn; $i++) {
							if ( 9 < strlen($csv_cnn[$i][8])  )

							{
				echo '<td bgcolor=#F0F8FF><img src="'.$csv_cnn[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_cnn[$i][7].'" target="_blank">'. $csv_cnn[$i][2] .'</a><i>'.	' (' . substr($csv_cnn[$i][8],0,11)  .')</i> '   .
									 				'<br>' . substr($csv_cnn[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>

</table>
</td></tr>
<!--  ---------===============    END CNN ==========   --->


<!--    breitbart PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_breitbart = array();

					 if(($handle_breitbart = fopen("data/breitbart.csv", "r")) !== FALSE)
					 {
					    while(($data_breitbart = fgetcsv($handle_breitbart,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_breitbart[] = $data_breitbart;
					    }
					 }

 					fclose($handle_breitbart);
							$result_breitbart = sizeof($csv_breitbart);



							echo '<td bgcolor ="#C36241">'.$csv_breitbart[1][0]. '</td></tr>';

							for($i = 1; $i < $result_breitbart ; $i++) {
							if (9 < strlen($csv_breitbart[$i][8]) ){
				echo '<td bgcolor=#FFDAB9><img src="'.$csv_breitbart[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_breitbart[$i][7].'" target="_blank">'. substr($csv_breitbart[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_breitbart[$i][8],0,11)  .')</i> '   .
																 				'<br>' . substr($csv_breitbart[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>


</table>
</td></tr>

<!-- ===================   END  breitbart============================== -->

<!--    abcnews PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_abcnews = array();

					 if(($handle_abcnews = fopen("data/abcnews.csv", "r")) !== FALSE)
					 {
					    while(($data_abcnews = fgetcsv($handle_abcnews,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_abcnews[] = $data_abcnews;
					    }
					 }

 					fclose($handle_abcnews);
							$result_abcnews = sizeof($csv_abcnews);


							#echo $result_abcnews;

							echo '<td bgcolor ="#98AFC7">'.$csv_abcnews[1][0]. '</td></tr>';

							for($i = 1; $i < $result_abcnews; $i++) {
							if (9 < strlen($csv_abcnews[$i][8]) )

							{
				echo '<td bgcolor=#F0F8FF><img src="'.$csv_abcnews[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_abcnews[$i][7].'" target="_blank">'. substr($csv_abcnews[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_abcnews[$i][8],0,11)  .')</i> '   .
									 				'<br>' . substr($csv_abcnews[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>


</table>
</td></tr>
<!--  ---------===============    END abcnews ==========   --->


<!--    foxnews PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_foxnews = array();

					 if(($handle_foxnews = fopen("data/foxnews.csv", "r")) !== FALSE)
					 {
					    while(($data_foxnews = fgetcsv($handle_foxnews,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_foxnews[] = $data_foxnews;
					    }
					 }

 					fclose($handle_foxnews);
							$result_foxnews = sizeof($csv_foxnews);



							echo '<td bgcolor ="#C36241">'.$csv_foxnews[1][0]. '</td></tr>';

							for($i = 1; $i < $result_foxnews ; $i++) {
							if (9 < strlen($csv_foxnews[$i][8]) ){
				echo '<td bgcolor=#FFDAB9><img src="'.$csv_foxnews[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_foxnews[$i][7].'" target="_blank">'. substr($csv_foxnews[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_foxnews[$i][8],0,11)  .')</i> '   .
																 				'<br>' . substr($csv_foxnews[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>


</table>
</td></tr>

<!-- ===================   END  foxnews============================== -->

<!--    abcnews PAPER -->
<tr> <td width=50% border=0 valign="Top">
<table border=0 width=100%  cellspacing="1" cellpadding="1">
<?PHP
					$csv_nbcnews = array();

					 if(($handle_nbcnews = fopen("data/nbcnews.csv", "r")) !== FALSE)
					 {
					    while(($data_nbcnews = fgetcsv($handle_nbcnews,  $length=8000,$separator = "," ,  $enclosure = '"',$escape = "\\")) !== FALSE)
					    {
					        $csv_nbcnews[] = $data_nbcnews;
					    }
					 }

 					fclose($handle_nbcnews);
							$result_nbcnews = sizeof($csv_nbcnews);


							#echo $result_nbcnews;

							echo '<td bgcolor ="#98AFC7">'.$csv_nbcnews[1][0]. '</td></tr>';

							for($i = 1; $i < $result_nbcnews; $i++) {
							if (9 < strlen($csv_nbcnews[$i][8]) )

							{
				echo '<td bgcolor=#F0F8FF><img src="'.$csv_nbcnews[$i][5].'" alt="Smiley face" height="22" width="22"><font size="2"><a href="'.$csv_nbcnews[$i][7].'" target="_blank">'. substr($csv_nbcnews[$i][2],0,250) .'</a><i>'.	' (' . substr($csv_nbcnews[$i][8],0,11)  .')</i> '   .
									 				'<br>' . substr($csv_nbcnews[$i][4],0,500) .
							'</font></td></tr>';
							}
							}

					  ?>


</table>
</td></tr>
<!--  ---------===============    END nbcnews ==========   --->






</table>

</body>
</html>