<html>
<head>
<title>Stock Sentiment</title>
<body>
<table border=1 width=100%  cellspacing="1" cellpadding="1">

<!-- HIGH SCORE SECTION COLUMN 1 ROW  1--->
<tr>
<td>
		<?php
			#================SETTING GLOBAL VARIABLES =============================================
					$time = strtotime('1990/05/11');
					$max_date= date('Y-m-d',$time);
					#echo $max_date. "<br>" ;
					$Symbol = '';
					$rank = 100;
					$reasons = [];
					$dt =[];
					$holder =[];
					$Select_Date=date('Y-m-d',$time);

			#####  READING FILE ###############

					if(($handle = fopen("data/High_Score_rank.csv", "r")) !== FALSE)
					{// read the headers
						while(($data = fgetcsv($handle)) !== FALSE)
						// read the data
						{
						$csv_rnk_idx[] = $data;
						$csv_rnk_idx_select[] = $data;
						######## GETTING DATE COLUMN IN $reasons ########
						$reasons[] = $data[0];
						}
					}fclose($handle);

			####  GETTING UNIQUE DATES AND BUILDING NEW ARRAY WITH DISTINCT VALUES ###########
				 $dt = array_unique($reasons);
				 $dt = array_values($dt);
			#######   GETTING LATEST DATE SO THAT REPORT OPENS WITH LATEST DATE DATA WHICH WILL BE USED IN ELSE STATEMENT ##########
				 $mt = strtotime('2000/01/01');
				 $md= date('Y-m-d',$mt);
				 $sz_1 = sizeof($dt);

				 for($i = 1; $i < $sz_1 ; $i++)
				 {
						if ($dt[$i] > $md)
						{
						  $md = $dt[$i];
						}
						else {

						$md = $md;
						}
				 }
				 #echo "MD = ".$md."<br>";

			### GETTING SIZE/NUMBER OF ROWS ##################
				 $sz = sizeof($dt);
				 $result_rnk_idx = sizeof($csv_rnk_idx);
				$result_rnk_idx_select = sizeof($csv_rnk_idx_select);
				#echo 'HELP'.$result_rnk_idx.'DONE';

			#### DEFAULT SECTION USED IN ELSE PART THIS SHOW DATA AS YOU OPEN THE PAGE BEFORE SELECTION ANY DATE #############
				for($i = 1; $i < $result_rnk_idx ; $i++) {
					$date= $csv_rnk_idx[$i][0];
					#echo $date;
					$Rank= $csv_rnk_idx[$i][1];
					$Symbol= $csv_rnk_idx[$i][2];
					$cmpd= $csv_rnk_idx[$i][3];
					$source= $csv_rnk_idx[$i][4];
					$content= $csv_rnk_idx[$i][5];

					 #if (($date > $max_date) & ($Rank < $rank))
					 #echo "Rank =".$Rank."rank =".$rank ;
					 if (($date == $md) & ($Rank < $rank)) {
					 #echo "Rank =".$Rank."rank =".$rank ;
					 $csv_rnk_clean_idx[] = array($date,$Symbol,$Rank,$content) ;
					 }
					}
					$rr = sizeof($csv_rnk_clean_idx);


		####   SELECTION SECTION THIS SECTION WILL ACTIVATE WHEN YOU SELECT A DATE #####################

			if(isset($_POST['stk']))
			{
					$choices= $_POST['stk'];
							if(isset($choices))
							{

									foreach ($choices as $key => $value)
									{
											$Select_Date = $value ;
											$max_date= date('Y-m-d',strtotime($value));
											#$max_date= $value ->format("Y-m-d") ;
											#strtotime($value);
											#echo "=== ".$value ->format("Y-m-d");
											#echo "Data Type".gettype($value) . "<br>";


								#echo " ----".date('Y-m-d',$value)."--".strtotime($value)."--".date('Y-m-d',strtotime($value))."<br>";
								###===================================###
										for($i = 1; $i < $result_rnk_idx_select ; $i++) {
											$date= $csv_rnk_idx_select[$i][0];
											#echo $date;
											$Rank= $csv_rnk_idx_select[$i][1];
											$Symbol= $csv_rnk_idx_select[$i][2];
											$cmpd= $csv_rnk_idx_select[$i][3];
											$source= $csv_rnk_idx[$i][4];
											$content= $csv_rnk_idx_select[$i][5];

											 if (($date == $max_date) & ($Rank < $rank))   {
											 $csv_rnk_clean_idx_select[] = array($date,$Symbol,$Rank,$content) ;
											 #echo "SC ".$csv_rnk_clean_idx_select[0][0]."<br>";
											 }
																	}
											$rr_select = sizeof($csv_rnk_clean_idx_select);

									#echo " SC : ".$csv_rnk_clean_idx_select[0][0]."<br>";
								###====================================##

								echo '<table border=1 width=100%  cellspacing="0" cellpadding="0">';

								    #### START OF TOP ROW ######
									echo '<tr><td colspan="4">';
										echo '<table border=0 width=100%  cellspacing="0" cellpadding="0">';
											echo '<tr><td colspan="2"  valign="Top"  align="right" bgcolor ="#d8d8d8" style="font-family:Courier New, Courier, monospace;font-size:100%">';
												echo '<form action="" method="post">  <br> <select name="stk[]" size="1" >';

												####  SELECT TEXT BOX COLUMN 1 ROW 1 #############
													for($i = 1; $i < $sz ; $i++)
																 {
																   echo ' <option   width="100" value="'.$dt[$i].' ">'.$dt[$i].'</option>';
																}
											echo'</select> 	<input type="submit" name="submit" value="Select"/> 	</form>';
											echo '</td> ';

											####  SELECT BUTTON COLUMN 2 ROW 1 #############
											#echo ' <td colspan="1"   valign="center" align="left" bgcolor ="#d8d8d8" style="font-family:Courier New, Courier, monospace;font-size:100%">';
											#echo '<br>';
											#		echo'</select> 	<input type="submit" name="submit" value=".................Select........"/> 	</form>';
											#echo '</td> ';

											############## HEADER Top Ranking Ticker for : date, COLUMN 3 ROW 1 ########################
											#echo ' <td colspan="1" valign="center" align="center" bgcolor ="#C0C0C0" >
										   echo ' <td colspan="2" valign="center" align="center" bgcolor ="#d8d8d8" style="font-family:Courier New, Courier, monospace;font-size:100%">
													<b>Ticker\'s with high sentiment on :' .$csv_rnk_clean_idx_select[0][0].'</b>
													</td> </tr>';
									    echo '</table>';
									echo '</td></tr>';

								########    END OF TOP ROW #########

								#### START OF COLUMN HEADER #################


									echo '<tr>  <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"><b> Ticker </b></td>
								   <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"><b> Rank </b></td>
								   <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"><b> Raw Content </b></td> </tr>';


								### END OF COLUMN HEADER ##############
								########## START OF ROWS ##############

									for($i = 0; $i < $rr_select ; $i++) {
										$class = ($i%2 == 0)? '#FFFFE0': '#BDB76B' ;
										#echo $_select[$i][0].','.$csv_rnk_clean_idx_select[$i][1].'<br>'  ;
										#echo 'SHUBRA:'.$csv_rnk_clean_idx_select[$i][1].'<br>'  ;
										echo '<tr> <td valign="center" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:70%">' .$csv_rnk_clean_idx_select[$i][1]. '</td>
										<td valign="center" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:70%">' .$csv_rnk_clean_idx_select[$i][2]. '</td>
										<td valign="Top" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:80%">' .$csv_rnk_clean_idx_select[$i][3]. '</td>  </tr>';
										}

								########## END OF ROWS ##############
										echo "</table>";

						}
				}
			}  ####  END OF  SELECTION SECTION  ######

		#### DEFAULT SECTION USED IN ELSE PART THIS SHOW DATA AS YOU OPEN THE PAGE BEFORE SELECTION ANY DATE #############

		 else

			 {
				echo '<table border=1 width=100%  cellspacing="0" cellpadding="0">';

						#### START OF TOP ROW ######
						echo '<tr><td colspan="4">';
						echo '<table border=0 width=100%  cellspacing="0" cellpadding="0">';
						echo '<tr><td  colspan="2"  valign="top" align="right" bgcolor ="#d8d8d8" style="font-family:Courier New, Courier, monospace;font-size:100%">';
							####  SELECT TEXT BOX COLUMN 1 ROW 1 #############
							echo '<form action="" method="post">  <br> <select name="stk[]" size="1" >';
												for($i = 1; $i < $sz ; $i++)
									 {
									   echo ' <option   width="100" value="'.$dt[$i].' ">'.$dt[$i].'</option>';
									}
									echo '</select> 	<input type="submit" name="submit" value="Select"/> 	</form>';
									echo '</td> ';

						  ####  BUTTON BOX COLUMN 2 ROW 1 #############
						  #echo ' <td colspan="1"  align="left" bgcolor ="#d8d8d8" style="font-family:Courier New, Courier, monospace;font-size:100%"> ';
						  #echo '<br>';
						  #echo '</select> 	<input type="submit" name="submit" value=".................Select........"/> 	</form>';
						  #echo '</td> ';

						  ############## HEADER Top Ranking Ticker for : date,COLUMN 3 ROW 1 ########################
						  #echo ' <td colspan="2" position="absolute" valign="top"  valign="center" align="center" bgcolor ="#C0C0C0" >
						  echo ' <td colspan="2" valign="center" align="center" bgcolor ="#d8d8d8" style="font-family:Courier New, Courier, monospace;font-size:100%">
						  <b>Ticker\'s with high sentiment on :' .$csv_rnk_clean_idx[0][0].
						  '</b></td></tr>';
						  echo '</table>';
					  echo '</td></tr>';
					  ########    END OF TOP ROW #########

				  #### START OF COLUMN HEADER #################
				  echo '<tr>  <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"> <b>Ticker</b> </td>
				  <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"> <b>Rank </b></td>
				  <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"> <b>Raw Content </b></td> </tr>';
				  ### END OF COLUMN HEADER ##############

				  ########## START OF ROWS ##############
					for($i = 0; $i < $rr ; $i++)
					{
					$class = ($i%2 == 0)? '#FFFFE0': '#BDB76B' ;
						#echo $csv_rnk_clean_idx[$i][0].','.$csv_rnk_clean_idx[$i][1].'<br>'  ;
						#echo 'SHUBRA1:'.$csv_rnk_clean_idx[$i][1].'<br>'  ;
						echo '<tr> <td valign="center" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:70%">' .$csv_rnk_clean_idx[$i][1]. '</td>
						<td valign="center" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:70%">' .$csv_rnk_clean_idx[$i][2]. '</td>
						<td valign="Top" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:80%">' .$csv_rnk_clean_idx[$i][3]. '</td>  </tr>';
					}
				  ########## END OF ROWS ##############

			echo "</table>";
		  }
		?>
</td>
</tr>
<!-- END OF HIGH SCORE SECTION --->
<tr>
<td bgcolor= '#000000'>
<BR>


<BR><BR><BR>
</td>
</tr>
<!-- LOW SCORE SECTION --->
<tr>
<td>
<?php
#================SETTING GLOBAL VARIABLES =============================================
		$time_low = strtotime('2020/05/11');
		$max_date_low= date('Y-m-d',$time_low);
		#echo $max_date_low. "<br>" ;
		$Symbol_low = '';
		$rank_low = 11;
		$reasons_low = [];
		$dt_low =[];
		$holder_low =[];
		$Select_Date_low=date('Y-m-d',$time_low);

#####  READING FILE ###############

		if(($handle_low = fopen("data/Low_Score_rank.csv", "r")) !== FALSE)
		{// read the headers
			while(($data_low = fgetcsv($handle_low)) !== FALSE)
			// read the data
			{
			$csv_rnk_idx_low[] = $data_low;
			$csv_rnk_idx_select_low[] = $data_low;
			######## GETTING DATE COLUMN IN $reasons ########
			$reasons_low[] = $data_low[0];
			}
		}fclose($handle_low);

####  GETTING UNIQUE DATES AND BUILDING NEW ARRAY WITH DISTINCT VALUES ###########
	 $dt_low = array_unique($reasons_low);
	 $dt_low = array_values($dt_low);
#######   GETTING LATEST DATE SO THAT REPORT OPENS WITH LATEST DATE DATA WHICH WILL BE USED IN ELSE STATEMENT ##########
	 $mt_low = strtotime('2000/01/01');
	 $md_low= date('Y-m-d',$mt_low);
	 $sz_1_low = sizeof($dt_low);

	 for($i = 1; $i < $sz_1_low ; $i++)
	 {
			if ($dt_low[$i] > $md_low)
			{
			  $md_low = $dt_low[$i];
			}
			else {

			$md_low = $md_low;
			}
	 }
	 #echo "MD = ".$md_low."<br>";

### GETTING SIZE/NUMBER OF ROWS ##################
	 $sz_low = sizeof($dt_low);
	 $result_rnk_idx_low = sizeof($csv_rnk_idx_low);
	$result_rnk_idx_select_low = sizeof($csv_rnk_idx_select_low);

#### DEFAULT SECTION USED IN ELSE PART THIS SHOW DATA AS YOU OPEN THE PAGE BEFORE SELECTION ANY DATE #############
	for($i = 1; $i < $result_rnk_idx_low ; $i++) {
		$date_low= $csv_rnk_idx_low[$i][0];
		#echo $date_low;
		$Rank_low= $csv_rnk_idx_low[$i][1];
		$Symbol_low= $csv_rnk_idx_low[$i][2];
		$cmpd_low= $csv_rnk_idx_low[$i][3];
		$source_low= $csv_rnk_idx_low[$i][4];
		$content_low= $csv_rnk_idx_low[$i][5];

		 #if (($date_low > $max_date_low) & ($Rank_low < $rank_low))
		 if (($date_low == $md_low) & ($Rank_low < $rank_low)) {
		 $csv_rnk_clean_idx_low[] = array($date_low,$Symbol_low,$Rank_low,$content_low) ;
		 }
		}
		$rr_low = sizeof($csv_rnk_clean_idx_low);


####   SELECTION SECTION THIS SECTION WILL ACTIVATE WHEN YOU SELECT A DATE #####################

	if(isset($_POST['stk']))
	{
			$choices= $_POST['stk'];
					if(isset($choices))
					{

							foreach ($choices as $key => $value_low)
							{
									$Select_Date_low = $value_low ;
									$max_date_low= date('Y-m-d',strtotime($value_low));
									#$max_date_low= $value_low ->format("Y-m-d") ;
									#strtotime($value_low);
									#echo "=== ".$value_low ->format("Y-m-d");
									#echo "Data Type".gettype($value_low) . "<br>";


						#						echo " ----".date('Y-m-d',$value_low)."--".strtotime($value_low)."--".date('Y-m-d',strtotime($value_low))."<br>";
						###===================================###
								for($i = 1; $i < $result_rnk_idx_select_low ; $i++) {
									$date_low= $csv_rnk_idx_select_low[$i][0];
									#echo $date_low;
									$Rank_low= $csv_rnk_idx_select_low[$i][1];
									$Symbol_low= $csv_rnk_idx_select_low[$i][2];
									$cmpd_low= $csv_rnk_idx_select_low[$i][3];
									$source_low= $csv_rnk_idx_low[$i][4];
									$content_low= $csv_rnk_idx_select_low[$i][5];

									 if (($date_low == $max_date_low) & ($Rank_low < $rank_low))   {
									 $csv_rnk_clean_idx_select_low[] = array($date_low,$Symbol_low,$Rank_low,$content_low) ;
									 #echo "SC ".$csv_rnk_clean_idx_select_low[0][0]."<br>";
									 }
															}
									$rr_select_low = sizeof($csv_rnk_clean_idx_select_low);

							#echo " SC : ".$csv_rnk_clean_idx_select_low[0][0]."<br>";
						###====================================##

						echo '<table border=1 width=100%  cellspacing="0" cellpadding="0">';

						#### START OF TOP ROW ######
							echo '<tr><td colspan="4">';
							echo '<table border=0 width=100%  cellspacing="0" cellpadding="0">';
							echo '<tr><td colspan="1" valign="center" align="right" bgcolor ="#D8EFFB" style="font-family:Courier New, Courier, monospace;font-size:80%">';
							#echo '<form action="" method="post">  <br> <select name="stk[]" size="1" >';

						####  SELECT TEXT BOX COLUMN 1 ROW 1 #############
							#for($i = 1; $i < $sz_low ; $i++)
							#			 {
							#			   echo ' <option width="100" value="'.$dt_low[$i].' ">'.$dt_low[$i].'</option>';
							#			}
							#			echo '</td> ';

						####  SELECT BUTTON COLUMN 2 ROW 1 #############
							echo ' <td colspan="1" valign="center" align="left" bgcolor ="#D8EFFB" style="font-family:Courier New, Courier, monospace;font-size:80%">';
							#echo'</select> 	<input type="submit" name="submit" value="Date"/> 	</form>';
							echo '</td> ';

						############## HEADER Top Ranking Ticker for : date, COLUMN 3 ROW 1 ########################
							#echo ' <td colspan="1" valign="center" align="center" bgcolor ="#C0C0C0" >
							echo ' <td colspan="2" valign="center" align="center" bgcolor ="#d8d8d8" style="font-family:Courier New, Courier, monospace;font-size:100%">
							<b>Ticker\'s with low sentiment on  :' .$csv_rnk_clean_idx_select_low[0][0].
							'</b></td> </tr>';
							echo '</table>';
							echo '</td></tr>';

						########    END OF TOP ROW #########

						#### START OF COLUMN HEADER #################


							echo '<tr>  <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"><b> Ticker </b></td>
						   <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"><b> Rank </b></td>
						   <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"><b>Raw Content </b></td> </tr>';


						### END OF COLUMN HEADER ##############
						########## START OF ROWS ##############

							for($i = 0; $i < $rr_select_low ; $i++) {

							$class = ($i%2 == 0)? '#FFFFE0': '#BDB76B' ; # '#D8EFFB'  '#f6ec05' "#B2DFF8" '#01eedc'  '#FFFF66'  '#FFFF99' '#FFEFD5' '#01eedc'  '#BDB76B' '#ADFF2F


								#echo $_select[$i][0].','.$csv_rnk_clean_idx_select[$i][1].'<br>'  ;
								echo '<tr> <td valign="center" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:70%">' .$csv_rnk_clean_idx_select_low[$i][1]. '</td>
								<td valign="center" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:70%">' .$csv_rnk_clean_idx_select_low[$i][2]. '</td>
								<td valign="Top" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:80%">' .$csv_rnk_clean_idx_select_low[$i][3]. '</td>  </tr>';
								}

						########## END OF ROWS ##############
								echo "</table>";

				}
		}
	}  ####  END OF  SELECTION SECTION  ######

#### DEFAULT SECTION USED IN ELSE PART THIS SHOW DATA AS YOU OPEN THE PAGE BEFORE SELECTION ANY DATE #############

 else

     {
		echo '<table border=1 width=100%  cellspacing="0" cellpadding="0">';

				#### START OF TOP ROW ######
				echo '<tr><td colspan="4">';
				echo '<table border=0 width=100%  cellspacing="0" cellpadding="0">';
				echo '<tr><td  colspan="1" valign="top" align="right" bgcolor ="#D8EFFB" style="font-family:Courier New, Courier, monospace;font-size:80%">';
					####  SELECT TEXT BOX COLUMN 1 ROW 1 #############
					#echo '<form action="" method="post">  <br> <select name="stk[]" size="1" >';
					#					for($i = 1; $i < $sz_low ; $i++)
				    #			 {
					#		   echo ' <option width="100" value="'.$dt_low[$i].' ">'.$dt_low[$i].'</option>';
					#		}
							echo '</td> ';

				  ####  BUTTON BOX COLUMN 2 ROW 1 #############
				  echo ' <td colspan="1" valign="center" align="left" bgcolor ="#D8EFFB" style="font-family:Courier New, Courier, monospace;font-size:80%"> ';
				  #echo '</select> 	<input type="submit" name="submit" value="Date"/> 	</form>';
				  echo '</td> ';

				  ############## HEADER Top Ranking Ticker for : date,COLUMN 3 ROW 1 ########################
				  #echo ' <td colspan="2" valign="center" align="center" bgcolor ="#C0C0C0" >
				  echo ' <td colspan="2" valign="center" align="center" bgcolor ="#d8d8d8" style="font-family:Courier New, Courier, monospace;font-size:100%">
				  <b>Ticker\'s with low sentiment on :' .$csv_rnk_clean_idx_low[0][0].
				  '</b></td></tr>';
				  echo '</table>';
			  echo '</td></tr>';
			  ########    END OF TOP ROW #########

		  #### START OF COLUMN HEADER #################
		  echo '<tr>  <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"> <b>Ticker</b> </td>
		  <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"> <b>Rank </b></td>
		  <td valign="Top" align="center" bgcolor ="#B6B6B6" style="font-family:Courier New, Courier, monospace;font-size:80%"> <b>Raw Content </b></td> </tr>';
		  ### END OF COLUMN HEADER ##############

		  ########## START OF ROWS ##############
			for($i = 0; $i < $rr_low ; $i++)
			{

			$class = ($i%2 == 0)? '#FFFFE0': '#BDB76B' ; # '#D8EFFB'  '#f6ec05' "#B2DFF8" '#01eedc'  '#FFFF66'  '#FFFF99' '#FFEFD5' '#01eedc'  '#BDB76B' '#ADFF2F

				echo '<tr > ';
				echo '<td valign="center" align="center"  bgcolor ='.$class.'  style="font-family:Courier New, Courier, monospace;font-size:70%">' .$csv_rnk_clean_idx_low[$i][1]. '</td>
				<td valign="center" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:70%">' .$csv_rnk_clean_idx_low[$i][2]. '</td>
				<td valign="Top" align="center" bgcolor ='.$class.' style="font-family:Courier New, Courier, monospace;font-size:80%">' .$csv_rnk_clean_idx_low[$i][3]. '</td>  </tr>';
			}
		  ########## END OF ROWS ##############

	echo "</table>";
  }
?>
</td>
</tr>
<!-- END OF LOW SCORE SECTION --->



</table>

</body>
</html>